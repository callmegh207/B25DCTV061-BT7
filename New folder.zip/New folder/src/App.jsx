import React, { useState } from 'react';

// ==================== BÀI 1: MÁY TÍNH ẢO ====================
function Calculator() {
  const [expression, setExpression] = useState('');

  const handleClick = (label) => {
    if (label === 'C') {
      setExpression('');
    } else if (label === '=') {
      try {
        const result = eval(expression.replace(/×/g, '*').replace(/÷/g, '/'));
        setExpression(String(result));
      } catch {
        setExpression('Lỗi');
      }
    } else {
      setExpression(prev => prev + label);
    }
  };

  return (
    <div style={{ textAlign: 'center', background: '#f4f4f4', padding: '25px', borderRadius: '12px', maxWidth: '320px', margin: '20px auto', boxShadow: '0 4px 10px rgba(0,0,0,0.1)' }}>
      <h3>Bài 1: Virtual Calculator</h3>
      <div style={{ background: '#222', color: '#fff', fontSize: '24px', padding: '15px', marginBottom: '15px', borderRadius: '6px', textAlign: 'right' }}>
        {expression || '0'}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
        {['7','8','9','÷', '4','5','6','×', '1','2','3','-', '0','.','=','+', 'C'].map((item, idx) => (
          <button 
            key={idx} 
            onClick={() => handleClick(item)}
            style={{ padding: '15px', fontSize: '16px', cursor: 'pointer', fontWeight: 'bold', background: item === '=' ? '#2196F3' : item === 'C' ? '#ff4d4d' : '#e0e0e0', color: item === '=' || item === 'C' ? '#fff' : '#000', border: 'none', borderRadius: '6px' }}
          >
            {item}
          </button>
        ))}
      </div>
    </div>
  );
}

// ==================== BÀI 2: TRANG CV CÁ NHÂN ====================
// Component Section dùng children
function Section({ title, children }) {
  return (
    <section style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ddd', borderRadius: '8px', background: '#fff' }}>
      <h3 style={{ borderBottom: '2px solid #007bff', paddingBottom: '8px', color: '#007bff', marginTop: 0 }}>{title}</h3>
      <div style={{ marginTop: '10px' }}>
        {children}
      </div>
    </section>
  );
}

// Component SkillList nhận mảng qua props
function SkillList({ skills }) {
  return (
    <ul style={{ display: 'flex', gap: '10px', listStyle: 'none', padding: 0, flexWrap: 'wrap' }}>
      {skills.map((skill, index) => (
        <li key={index} style={{ background: '#e9ecef', padding: '6px 12px', borderRadius: '6px', fontWeight: '500' }}>
          {skill}
        </li>
      ))}
    </ul>
  );
}

// Component ProjectList nhận mảng qua props
function ProjectList({ projects }) {
  return (
    <div>
      {projects.map((proj, index) => (
        <div key={index} style={{ marginBottom: '12px' }}>
          <h4 style={{ margin: '0 0 4px 0', color: '#333' }}>{proj.name}</h4>
          <p style={{ margin: 0, color: '#666', fontSize: '14px' }}>{proj.description}</p>
        </div>
      ))}
    </div>
  );
}

function CvPage() {
  const skillsData = ['ReactJS', 'JavaScript', 'Python', 'Git & VS Code'];
  const projectsData = [
    { name: 'PoseAlert AI', description: 'Ứng dụng giám sát tư thế sử dụng MediaPipe Pose và Python.' },
    { name: 'Virtual Calculator', description: 'Máy tính bỏ túi cá nhân xây dựng bằng ReactJS.' }
  ];

  return (
    <div style={{ maxWidth: '600px', margin: '20px auto', background: '#fff', padding: '20px', borderRadius: '10px', boxShadow: '0 4px 10px rgba(0,0,0,0.05)' }}>
      <header style={{ textAlign: 'center', marginBottom: '25px' }}>
        <h2 style={{ margin: '0 0 5px 0', color: '#222' }}>Trần Đình Phúc</h2>
        <p style={{ margin: 0, color: '#666' }}>Sinh viên ngành AIoT - PTIT | Lập trình viên tập sự</p>
      </header>

      <Section title="Kỹ năng chuyên môn">
        <SkillList skills={skillsData} />
      </Section>

      <Section title="Dự án nổi bật">
        <ProjectList projects={projectsData} />
      </Section>
    </div>
  );
}

// ==================== COMPONENT CHÍNH QUẢN LÝ TAB ====================
export default function App() {
  const [activeTab, setActiveTab] = useState('calc'); // Mặc định hiển thị Bài 1

  return (
    <div style={{ padding: '30px', maxWidth: '750px', margin: '0 auto', fontFamily: 'Arial, sans-serif', background: '#f8f9fa', minHeight: '100vh' }}>
      <h1 style={{ textAlign: 'center', color: '#333', marginBottom: '20px' }}>Bài tập Lập trình Web - Buổi 7</h1>
      
      {/* Thanh điều hướng chuyển đổi giữa Bài 1 và Bài 2 */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: '15px', marginBottom: '30px' }}>
        <button 
          onClick={() => setActiveTab('calc')}
          style={{ padding: '10px 20px', fontSize: '16px', fontWeight: 'bold', cursor: 'pointer', background: activeTab === 'calc' ? '#007bff' : '#e0e0e0', color: activeTab === 'calc' ? '#fff' : '#333', border: 'none', borderRadius: '6px' }}
        >
          Bài 1: Máy tính ảo
        </button>
        <button 
          onClick={() => setActiveTab('cv')}
          style={{ padding: '10px 20px', fontSize: '16px', fontWeight: 'bold', cursor: 'pointer', background: activeTab === 'cv' ? '#007bff' : '#e0e0e0', color: activeTab === 'cv' ? '#fff' : '#333', border: 'none', borderRadius: '6px' }}
        >
          Bài 2: Trang CV cá nhân
        </button>
      </div>

      {/* Hiển thị nội dung tương ứng với Tab được chọn */}
      {activeTab === 'calc' ? <Calculator /> : <CvPage />}
    </div>
  );
}